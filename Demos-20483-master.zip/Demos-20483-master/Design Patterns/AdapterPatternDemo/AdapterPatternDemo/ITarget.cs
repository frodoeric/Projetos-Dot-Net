namespace AdapterPatternDemo
{
	public interface ITarget
	{
		string Request(int i);
	}
}