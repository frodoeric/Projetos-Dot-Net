﻿using System;
using ConsoleApplication1;

namespace Dependency2
{
    public class Cachorro : IFalante
    {
        public void DigaOla()
        {
            Console.WriteLine("Au Au");
        }
    }
}
