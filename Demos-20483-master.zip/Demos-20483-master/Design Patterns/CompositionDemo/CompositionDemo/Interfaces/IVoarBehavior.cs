﻿namespace CompositionDemo.Interfaces
{
	public interface IVoarBehavior
	{
		void Voar();
	}
}