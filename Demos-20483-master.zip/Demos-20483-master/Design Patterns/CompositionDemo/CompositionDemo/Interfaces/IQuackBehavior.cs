﻿namespace CompositionDemo.Interfaces
{
	public interface IQuackBehavior
	{
		void Quack();
	}
}