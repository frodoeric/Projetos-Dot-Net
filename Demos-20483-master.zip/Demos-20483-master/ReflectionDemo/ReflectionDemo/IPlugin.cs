﻿namespace ReflectionDemo
{
	public interface IPlugin
	{
		string Nome { get; }
		string Mensagem();
	}
}
